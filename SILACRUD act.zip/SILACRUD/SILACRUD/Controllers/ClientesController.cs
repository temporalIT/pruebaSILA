﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using SILACRUD.Models;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.Extensions.Configuration;

namespace SILACRUD.Controllers
{
    public class ClientesController : Controller
    {
        private readonly IConfiguration _configuration;
        private readonly string _connectionString;

        public ClientesController(IConfiguration configuration)
        {
            _configuration = configuration;
            _connectionString = _configuration.GetConnectionString("DefaultConnection");
        }


        // GET: ClientesController
        [HttpGet]
        public ActionResult Index(decimal? searchCodigo = null)
        {
            DataTable dtblClientes = new DataTable();
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();
                using (SqlCommand sqlCmd = new SqlCommand("sp_sila_clientes", sqlCon))
                {
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@tipooperacion", 4);
                    sqlCmd.Parameters.AddWithValue("@codigo", searchCodigo.HasValue ? (object)searchCodigo.Value : DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@pais", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@canal", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@nombre_comercial", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@nombre_lasante", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@tipo_cliente", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@direccion", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@departamento", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@municipio", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@contacto", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@telefono", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@sitioweb", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@promotor", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@estado", 1);
                    sqlCmd.Parameters.AddWithValue("@referencia", DBNull.Value);

                    SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);
                    sqlDa.Fill(dtblClientes);
                }
            }
            ViewData["CurrentFilter"] = searchCodigo;
            return View(dtblClientes);
        }

        // GET: ClientesController/Details/5
        public ActionResult Details(int id)
        {
            ClientesModel clientesModel = new ClientesModel();
            DataTable dtblClientes = new DataTable();
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();

                SqlCommand sqlCmd = new SqlCommand("sp_sila_clientes", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                sqlCmd.Parameters.AddWithValue("@tipooperacion", 2);
                sqlCmd.Parameters.AddWithValue("@codigo", id); 
                sqlCmd.Parameters.AddWithValue("@pais", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@canal", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@nombre_comercial", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@nombre_lasante", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@tipo_cliente", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@direccion", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@departamento", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@municipio", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@contacto", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@telefono", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@sitioweb", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@promotor", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@estado", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@referencia", DBNull.Value);

                SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);
                sqlDa.Fill(dtblClientes);
            }
            if (dtblClientes.Rows.Count == 1)
            {
                clientesModel.codigo = Convert.ToInt32(dtblClientes.Rows[0]["codigo"].ToString());
                clientesModel.pais = dtblClientes.Rows[0]["pais"].ToString();
                clientesModel.canal = Convert.ToInt32(dtblClientes.Rows[0]["canal"].ToString());
                clientesModel.nombre_comercial = dtblClientes.Rows[0]["nombre_comercial"].ToString();
                clientesModel.nombre_lasante = dtblClientes.Rows[0]["nombre_lasante"].ToString();
                clientesModel.tipo_cliente = Convert.ToInt32(dtblClientes.Rows[0]["tipo_cliente"].ToString());
                clientesModel.direccion = dtblClientes.Rows[0]["direccion"].ToString();
                clientesModel.departamento = Convert.ToInt32(dtblClientes.Rows[0]["departamento"].ToString());
                clientesModel.municipio = Convert.ToInt32(dtblClientes.Rows[0]["municipio"].ToString());
                clientesModel.contacto = dtblClientes.Rows[0]["contacto"].ToString();
                clientesModel.telefono = dtblClientes.Rows[0]["telefono"].ToString();
                clientesModel.sitioweb = dtblClientes.Rows[0]["sitioweb"].ToString();
                clientesModel.promotor = Convert.ToInt32(dtblClientes.Rows[0]["promotor"].ToString());
                clientesModel.estado = Convert.ToInt32(dtblClientes.Rows[0]["estado"].ToString());
                clientesModel.referencia = dtblClientes.Rows[0]["referencia"].ToString();
                return View(clientesModel);
            }
            else
            {
                return RedirectToAction("Index");
            }
        }

        // GET: ClientesController/Create
        public ActionResult Create()
        {
            return View(new ClientesModel());
        }

        // POST: ClientesController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(ClientesModel clientesModel)
        {
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();

                SqlCommand sqlCmd = new SqlCommand("sp_sila_clientes", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                sqlCmd.Parameters.AddWithValue("@tipooperacion", 1);
                sqlCmd.Parameters.AddWithValue("@codigo", clientesModel.codigo);
                sqlCmd.Parameters.AddWithValue("@pais", clientesModel.pais ?? (object)DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@canal", clientesModel.canal);
                sqlCmd.Parameters.AddWithValue("@nombre_comercial", clientesModel.nombre_comercial ?? (object)DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@nombre_lasante", clientesModel.nombre_lasante ?? (object)DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@tipo_cliente", clientesModel.tipo_cliente);
                sqlCmd.Parameters.AddWithValue("@direccion", clientesModel.direccion ?? (object)DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@departamento", clientesModel.departamento);
                sqlCmd.Parameters.AddWithValue("@municipio", clientesModel.municipio);
                sqlCmd.Parameters.AddWithValue("@contacto", clientesModel.contacto ?? (object)DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@telefono", clientesModel.telefono ?? (object)DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@sitioweb", clientesModel.sitioweb ?? (object)DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@promotor", clientesModel.promotor);
                sqlCmd.Parameters.AddWithValue("@estado", 1);
                sqlCmd.Parameters.AddWithValue("@referencia", clientesModel.referencia ?? (object)DBNull.Value);
                sqlCmd.ExecuteNonQuery();

            }
            return RedirectToAction("Index");
        }

        // GET: ClientesController/Edit/5
        public ActionResult Edit(int id)
        {
            ClientesModel clientesModel = new ClientesModel();
            DataTable dtblClientes = new DataTable();
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();

                SqlCommand sqlCmd = new SqlCommand("sp_sila_clientes", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                sqlCmd.Parameters.AddWithValue("@tipooperacion", 2);
                sqlCmd.Parameters.AddWithValue("@codigo", id); 
                sqlCmd.Parameters.AddWithValue("@pais", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@canal", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@nombre_comercial", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@nombre_lasante", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@tipo_cliente", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@direccion", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@departamento", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@municipio", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@contacto", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@telefono", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@sitioweb", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@promotor", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@estado", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@referencia", DBNull.Value);

                SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);
                sqlDa.Fill(dtblClientes);
            }
            if (dtblClientes.Rows.Count == 1)
            {
                clientesModel.codigo = Convert.ToInt32(dtblClientes.Rows[0]["codigo"].ToString());
                clientesModel.pais = dtblClientes.Rows[0]["pais"].ToString();
                clientesModel.canal = Convert.ToInt32(dtblClientes.Rows[0]["canal"].ToString());
                clientesModel.nombre_comercial = dtblClientes.Rows[0]["nombre_comercial"].ToString();
                clientesModel.nombre_lasante = dtblClientes.Rows[0]["nombre_lasante"].ToString();
                clientesModel.tipo_cliente = Convert.ToInt32(dtblClientes.Rows[0]["tipo_cliente"].ToString());
                clientesModel.direccion = dtblClientes.Rows[0]["direccion"].ToString();
                clientesModel.departamento = Convert.ToInt32(dtblClientes.Rows[0]["departamento"].ToString());
                clientesModel.municipio = Convert.ToInt32(dtblClientes.Rows[0]["municipio"].ToString());
                clientesModel.contacto = dtblClientes.Rows[0]["contacto"].ToString();
                clientesModel.telefono = dtblClientes.Rows[0]["telefono"].ToString();
                clientesModel.sitioweb = dtblClientes.Rows[0]["sitioweb"].ToString();
                clientesModel.promotor = Convert.ToInt32(dtblClientes.Rows[0]["promotor"].ToString());
                clientesModel.estado = Convert.ToInt32(dtblClientes.Rows[0]["estado"].ToString());
                clientesModel.referencia = dtblClientes.Rows[0]["referencia"].ToString();
                return View(clientesModel);         

            }
            else
            {
                return RedirectToAction("Index");
            }
        }

        // POST: ClientesController/Edit/5
        [HttpPost]
        public ActionResult Edit(ClientesModel clientesModel)
        {
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();
                using (SqlCommand sqlCmd = new SqlCommand("sp_sila_clientes", sqlCon))
                {
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@tipooperacion", 3);
                    sqlCmd.Parameters.AddWithValue("@codigo", clientesModel.codigo);
                    sqlCmd.Parameters.AddWithValue("@pais", clientesModel.pais ?? (object)DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@canal", clientesModel.canal);
                    sqlCmd.Parameters.AddWithValue("@nombre_comercial", clientesModel.nombre_comercial ?? (object)DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@nombre_lasante", clientesModel.nombre_lasante ?? (object)DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@tipo_cliente", clientesModel.tipo_cliente);
                    sqlCmd.Parameters.AddWithValue("@direccion", clientesModel.direccion ?? (object)DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@departamento", clientesModel.departamento);
                    sqlCmd.Parameters.AddWithValue("@municipio", clientesModel.municipio);
                    sqlCmd.Parameters.AddWithValue("@contacto", clientesModel.contacto ?? (object)DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@telefono", clientesModel.telefono ?? (object)DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@sitioweb", clientesModel.sitioweb ?? (object)DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@promotor", clientesModel.promotor);
                    sqlCmd.Parameters.AddWithValue("@estado", clientesModel.estado);
                    sqlCmd.Parameters.AddWithValue("@referencia", clientesModel.referencia ?? (object)DBNull.Value);
                    sqlCmd.ExecuteNonQuery();
                }
            }
            return RedirectToAction("Index");
        }

        // GET: ClientesController/Delete/5
        [HttpGet]
        public ActionResult Delete(int id)
        {
            ClientesModel clientesModel = new ClientesModel();
            DataTable dtblClientes = new DataTable();
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();

                SqlCommand sqlCmd = new SqlCommand("sp_sila_clientes", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                sqlCmd.Parameters.AddWithValue("@tipooperacion", 2);
                sqlCmd.Parameters.AddWithValue("@codigo", id); 
                sqlCmd.Parameters.AddWithValue("@pais", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@canal", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@nombre_comercial", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@nombre_lasante", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@tipo_cliente", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@direccion", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@departamento", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@municipio", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@contacto", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@telefono", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@sitioweb", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@promotor", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@estado", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@referencia", DBNull.Value);

                SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);
                sqlDa.Fill(dtblClientes);
            }
            if (dtblClientes.Rows.Count == 1)
            {
                clientesModel.codigo = Convert.ToInt32(dtblClientes.Rows[0]["codigo"].ToString());
                clientesModel.pais = dtblClientes.Rows[0]["pais"].ToString();
                clientesModel.canal = Convert.ToInt32(dtblClientes.Rows[0]["canal"].ToString());
                clientesModel.nombre_comercial = dtblClientes.Rows[0]["nombre_comercial"].ToString();
                clientesModel.nombre_lasante = dtblClientes.Rows[0]["nombre_lasante"].ToString();
                clientesModel.tipo_cliente = Convert.ToInt32(dtblClientes.Rows[0]["tipo_cliente"].ToString());
                clientesModel.direccion = dtblClientes.Rows[0]["direccion"].ToString();
                clientesModel.departamento = Convert.ToInt32(dtblClientes.Rows[0]["departamento"].ToString());
                clientesModel.municipio = Convert.ToInt32(dtblClientes.Rows[0]["municipio"].ToString());
                clientesModel.contacto = dtblClientes.Rows[0]["contacto"].ToString();
                clientesModel.telefono = dtblClientes.Rows[0]["telefono"].ToString();
                clientesModel.sitioweb = dtblClientes.Rows[0]["sitioweb"].ToString();
                clientesModel.promotor = Convert.ToInt32(dtblClientes.Rows[0]["promotor"].ToString());
                clientesModel.estado = Convert.ToInt32(dtblClientes.Rows[0]["estado"].ToString());
                clientesModel.referencia = dtblClientes.Rows[0]["referencia"].ToString(); 
                return View(clientesModel);
            }
            else
            {
                return RedirectToAction("Index");
            }
        }

        // POST: ClientesController/Delete/5
        [HttpPost]
        public ActionResult DeleteConfirmed(int id)
        {
            try
            {
                using (SqlConnection sqlCon = new SqlConnection(_connectionString))
                {
                    sqlCon.Open();
                    using (SqlCommand sqlCmd = new SqlCommand("sp_sila_clientes", sqlCon))
                    {
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.Parameters.AddWithValue("@tipooperacion", 5);
                        sqlCmd.Parameters.AddWithValue("@codigo", id);
                        sqlCmd.Parameters.AddWithValue("@pais", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@canal", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@nombre_comercial", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@nombre_lasante", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@tipo_cliente", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@direccion", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@departamento", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@municipio", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@contacto", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@telefono", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@sitioweb", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@promotor", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@estado", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@referencia", DBNull.Value);

                        int rowsAffected = sqlCmd.ExecuteNonQuery();

                        if (rowsAffected == 0)
                        {
                            TempData["ErrorMessage"] = "No se encontró el cliente especificado.";
                        }
                        else
                        {
                            TempData["SuccessMessage"] = "Estado del cliente actualizado exitosamente.";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Ocurrió un error al intentar actualizar el estado del cliente. Por favor, intente de nuevo.";
            }
            return RedirectToAction("Index");
        }
    }
}