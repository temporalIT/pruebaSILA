﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using SILACRUD.Models;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.Extensions.Configuration;

namespace SILACRUD.Controllers
{
    public class Geo_DepartamentosController : Controller
    {
        private readonly IConfiguration _configuration;
        private readonly string _connectionString;

        public Geo_DepartamentosController(IConfiguration configuration)
        {
            _configuration = configuration;
            _connectionString = _configuration.GetConnectionString("DefaultConnection");
        }

        // GET: Geo_DepartamentosController
        [HttpGet]
        public ActionResult Index(string searchDepartamentos = null)
        {
            DataTable dtblDepartamentos = new DataTable();
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();
                using (SqlCommand sqlCmd = new SqlCommand("sp_sila_geo_departamentos", sqlCon))
                {
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@tipooperacion", 4);
                    sqlCmd.Parameters.AddWithValue("@id", string.IsNullOrEmpty(searchDepartamentos) ? (object)DBNull.Value : searchDepartamentos);
                    sqlCmd.Parameters.AddWithValue("@pais", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@codigo", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@nombre", DBNull.Value);

                    SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);
                    sqlDa.Fill(dtblDepartamentos);
                }
            }
            ViewData["CurrentFilter"] = searchDepartamentos;
            return View(dtblDepartamentos);
        }

        // GET: Geo_DepartamentosController/Details/5
        public ActionResult Details(string id)
        {
            Geo_DepartamentosModel geo_departamentosModel = new Geo_DepartamentosModel();
            DataTable dtblDepartamentos = new DataTable();
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();

                SqlCommand sqlCmd = new SqlCommand("sp_sila_geo_departamentos", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                sqlCmd.Parameters.AddWithValue("@tipooperacion", 2);
                sqlCmd.Parameters.AddWithValue("@id", id);
                sqlCmd.Parameters.AddWithValue("@pais", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@codigo", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@nombre", DBNull.Value);

                SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);
                sqlDa.Fill(dtblDepartamentos);
            }
            if (dtblDepartamentos.Rows.Count == 1)
            {
                geo_departamentosModel.id = dtblDepartamentos.Rows[0]["id"].ToString();
                geo_departamentosModel.pais = dtblDepartamentos.Rows[0]["pais"].ToString();
                geo_departamentosModel.codigo = Convert.ToInt32(dtblDepartamentos.Rows[0]["codigo"].ToString());
                geo_departamentosModel.nombre = dtblDepartamentos.Rows[0]["nombre"].ToString();
                return View(geo_departamentosModel);
            }
            else
            {
                return RedirectToAction("Index");
            }
        }

        // GET: Geo_DepartamentosController/Create
        public ActionResult Create()
        {
            return View(new Geo_DepartamentosModel());
        }

        // POST: Geo_DepartamentosController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Geo_DepartamentosModel geo_departamentosModel)
        {
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();

                SqlCommand sqlCmd = new SqlCommand("sp_sila_geo_departamentos", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;


                sqlCmd.Parameters.AddWithValue("@tipooperacion", 1);
                sqlCmd.Parameters.AddWithValue("@id", geo_departamentosModel.id ?? (object)DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@pais", geo_departamentosModel.pais ?? (object)DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@codigo", geo_departamentosModel.codigo);
                sqlCmd.Parameters.AddWithValue("@nombre", geo_departamentosModel.nombre ?? (object)DBNull.Value);
                sqlCmd.ExecuteNonQuery();
            }
            return RedirectToAction("Index");
        }

        // GET: Geo_DepartamentosController/Edit/5
        public ActionResult Edit(string id)
        {
            Geo_DepartamentosModel geo_departamentosModel = new Geo_DepartamentosModel();
            DataTable dtblDepartamentos = new DataTable();
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();

                SqlCommand sqlCmd = new SqlCommand("sp_sila_geo_departamentos", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                sqlCmd.Parameters.AddWithValue("@tipooperacion", 2);
                sqlCmd.Parameters.AddWithValue("@id", id);
                sqlCmd.Parameters.AddWithValue("@pais", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@codigo", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@nombre", DBNull.Value);

                SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);
                sqlDa.Fill(dtblDepartamentos);
            }
            if (dtblDepartamentos.Rows.Count == 1)
            {
                geo_departamentosModel.id = dtblDepartamentos.Rows[0]["id"].ToString();
                geo_departamentosModel.pais = dtblDepartamentos.Rows[0]["pais"].ToString();
                geo_departamentosModel.codigo = Convert.ToInt32(dtblDepartamentos.Rows[0]["codigo"].ToString());
                geo_departamentosModel.nombre = dtblDepartamentos.Rows[0]["nombre"].ToString();
                return View(geo_departamentosModel);
            }
            else
            {
                return RedirectToAction("Index");
            }
        }

        // POST: Geo_DepartamentosController/Edit/5
        [HttpPost]
        public ActionResult Edit(Geo_DepartamentosModel geo_departamentosModel)
        {
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();
                using (SqlCommand sqlCmd = new SqlCommand("sp_sila_geo_departamentos", sqlCon))
                {
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@tipooperacion", 3);
                    sqlCmd.Parameters.AddWithValue("@id", geo_departamentosModel.id ?? (object)DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@pais", geo_departamentosModel.pais ?? (object)DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@codigo", geo_departamentosModel.codigo);
                    sqlCmd.Parameters.AddWithValue("@nombre", geo_departamentosModel.nombre ?? (object)DBNull.Value);
                    sqlCmd.ExecuteNonQuery();
                }
            }
            return RedirectToAction("Index");
        }

        // GET: Geo_DepartamentosController/Delete/5
        [HttpGet]
        public ActionResult Delete(string id)
        {
            Geo_DepartamentosModel geo_departamentosModel = new Geo_DepartamentosModel();
            DataTable dtblDepartamentos = new DataTable();
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();

                SqlCommand sqlCmd = new SqlCommand("sp_sila_geo_departamentos", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                sqlCmd.Parameters.AddWithValue("@tipooperacion", 2);
                sqlCmd.Parameters.AddWithValue("@id", id);
                sqlCmd.Parameters.AddWithValue("@pais", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@codigo", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@nombre", DBNull.Value);

                SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);
                sqlDa.Fill(dtblDepartamentos);
            }
            if (dtblDepartamentos.Rows.Count == 1)
            {
                geo_departamentosModel.id = dtblDepartamentos.Rows[0]["id"].ToString();
                geo_departamentosModel.pais = dtblDepartamentos.Rows[0]["pais"].ToString();
                geo_departamentosModel.codigo = Convert.ToInt32(dtblDepartamentos.Rows[0]["codigo"].ToString());
                geo_departamentosModel.nombre = dtblDepartamentos.Rows[0]["nombre"].ToString();
                return View(geo_departamentosModel);
            }
            else
            {
                return RedirectToAction("Index");
            }
        }

        // POST: Geo_DepartamentosController/Delete/5
        [HttpPost]
        public ActionResult DeleteConfirmed(string id)
        {
            try
            {
                using (SqlConnection sqlCon = new SqlConnection(_connectionString))
                {
                    sqlCon.Open();
                    using (SqlCommand sqlCmd = new SqlCommand("sp_sila_geo_departamentos", sqlCon))
                    {
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.Parameters.AddWithValue("@tipooperacion", 5);
                        sqlCmd.Parameters.AddWithValue("@id", id);
                        sqlCmd.Parameters.AddWithValue("@pais", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@codigo", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@nombre", DBNull.Value);

                        int rowsAffected = sqlCmd.ExecuteNonQuery();

                        if (rowsAffected == 0)
                        {
                            TempData["ErrorMessage"] = "No se encontró el departamento especificado.";
                        }
                        else
                        {
                            TempData["SuccessMessage"] = "Departamento eliminado exitosamente.";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Ocurrió un error al intentar eliminar el departamento. Por favor, intente de nuevo.";
            }
            return RedirectToAction("Index");
        }
    }
}