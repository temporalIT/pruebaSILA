﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SILACRUD.Models;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SILACRUD.Controllers
{
    public class UsuariosController : Controller
    {

        private readonly IConfiguration _configuration;
        private readonly string _connectionString;

        public UsuariosController(IConfiguration configuration)
        {
            _configuration = configuration;
            _connectionString = _configuration.GetConnectionString("DefaultConnection");
        }


        [HttpGet]
        public ActionResult Index(string searchString = "")
        {
            DataTable dtblUsuarios = new DataTable();
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();
                using (SqlCommand sqlCmd = new SqlCommand("sp_sila_usuarios", sqlCon))
                {
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@tipooperacion", 4);
                    sqlCmd.Parameters.AddWithValue("@usuarios", string.IsNullOrEmpty(searchString) ? (object)DBNull.Value : searchString);
                    sqlCmd.Parameters.AddWithValue("@permisos", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@estado", 1);


                    SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);
                    sqlDa.Fill(dtblUsuarios);
                }
            }
            ViewData["CurrentFilter"] = searchString;
            return View(dtblUsuarios);
        }



        // GET: UsuariosController/Details/5
        public ActionResult Details(string id)
        {
            UsuariosModel usuariosModel = new UsuariosModel();
            DataTable dtblUsuario = new DataTable();
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();

                SqlCommand sqlCmd = new SqlCommand("sp_sila_usuarios", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                sqlCmd.Parameters.AddWithValue("@tipooperacion", 2);
                sqlCmd.Parameters.AddWithValue("@usuarios", id);
                sqlCmd.Parameters.AddWithValue("@permisos", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@estado", DBNull.Value);

                SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);
                sqlDa.Fill(dtblUsuario);
            }
            if (dtblUsuario.Rows.Count == 1)
            {
                usuariosModel.usuarios = dtblUsuario.Rows[0]["usuarios"].ToString();
                usuariosModel.permisos = dtblUsuario.Rows[0]["permisos"].ToString();
                usuariosModel.estado = Convert.ToInt32(dtblUsuario.Rows[0]["estado"].ToString());
                return View(usuariosModel);
            }
            else
            {
                return RedirectToAction("Index");
            }
        }


        // GET: UsuariosController/Create
        [HttpGet]
        public ActionResult Create()
        {
            return View(new UsuariosModel());
        }

        // POST: UsuariosController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(UsuariosModel usuariosModel)
        {
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();

                SqlCommand sqlCmd = new SqlCommand("sp_sila_usuarios", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;


                sqlCmd.Parameters.AddWithValue("@tipooperacion", 1);
                sqlCmd.Parameters.AddWithValue("@usuarios", usuariosModel.usuarios);
                sqlCmd.Parameters.AddWithValue("@permisos", usuariosModel.permisos ?? (object)DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@estado", 1);
                sqlCmd.ExecuteNonQuery();

            }
            return RedirectToAction("Index");
        }

        // GET: UsuariosController/Edit/5
        public ActionResult Edit(string id)
        {
            UsuariosModel usuariosModel = new UsuariosModel();
            DataTable dtblUsuarios = new DataTable();
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();

                SqlCommand sqlCmd = new SqlCommand("sp_sila_usuarios", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                sqlCmd.Parameters.AddWithValue("@tipooperacion", 2);
                sqlCmd.Parameters.AddWithValue("@usuarios", id);
                sqlCmd.Parameters.AddWithValue("@permisos", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@estado", DBNull.Value);

                SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);
                sqlDa.Fill(dtblUsuarios);
            }
            if (dtblUsuarios.Rows.Count == 1)
            {
                usuariosModel.usuarios = dtblUsuarios.Rows[0]["usuarios"].ToString();
                usuariosModel.permisos = dtblUsuarios.Rows[0]["permisos"].ToString();
                usuariosModel.estado = Convert.ToInt32(dtblUsuarios.Rows[0]["estado"].ToString());
                return View(usuariosModel);
            }
            else
            {
                return RedirectToAction("Index");
            }
        }

        // POST: UsuariosController/Edit/5
        [HttpPost]
        
        public ActionResult Edit(UsuariosModel usuariosModel)
        {
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();
                using (SqlCommand sqlCmd = new SqlCommand("sp_sila_usuarios", sqlCon))
                {
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@tipooperacion", 3);
                    sqlCmd.Parameters.AddWithValue("@usuarios", usuariosModel.usuarios);
                    sqlCmd.Parameters.AddWithValue("@permisos", usuariosModel.permisos ?? (object)DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@estado", usuariosModel.estado);

                    sqlCmd.ExecuteNonQuery();
                }
            }
            return RedirectToAction("Index");
        }


        [HttpGet]
        public ActionResult Delete(string id)
        {
            UsuariosModel usuariosModel = new UsuariosModel();
            DataTable dtblUsuarios = new DataTable();
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();

                SqlCommand sqlCmd = new SqlCommand("sp_sila_usuarios", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                sqlCmd.Parameters.AddWithValue("@tipooperacion", 2);
                sqlCmd.Parameters.AddWithValue("@usuarios", id);
                sqlCmd.Parameters.AddWithValue("@permisos", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@estado", DBNull.Value);

                SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);
                sqlDa.Fill(dtblUsuarios);
            }
            if (dtblUsuarios.Rows.Count == 1)
            {
                usuariosModel.usuarios = dtblUsuarios.Rows[0]["usuarios"].ToString();
                usuariosModel.permisos = dtblUsuarios.Rows[0]["permisos"].ToString();
                usuariosModel.estado = Convert.ToInt32(dtblUsuarios.Rows[0]["estado"].ToString());
                return View(usuariosModel);
            }
            else
            {
                return RedirectToAction("Index");
            }
        }


        // GET: UsuariosController/Delete/5
        [HttpPost]
        public ActionResult DeleteConfirmed(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                return RedirectToAction("Index");
            }

            try
            {
                using (SqlConnection sqlCon = new SqlConnection(_connectionString))
                {
                    sqlCon.Open();
                    using (SqlCommand sqlCmd = new SqlCommand("sp_sila_usuarios", sqlCon))
                    {
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.Parameters.AddWithValue("@tipooperacion", 5);
                        sqlCmd.Parameters.AddWithValue("@usuarios", id);
                        sqlCmd.Parameters.AddWithValue("@permisos", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@estado", DBNull.Value);

                        int rowsAffected = sqlCmd.ExecuteNonQuery();

                        if (rowsAffected == 0)
                        {
                            TempData["ErrorMessage"] = "No se encontró el usuario especificado.";
                        }
                        else
                        {
                            TempData["SuccessMessage"] = "Estado del usuario actualizado exitosamente.";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Ocurrió un error al intentar actualizar el estado del usuario. Por favor, intente de nuevo.";
            }
            return RedirectToAction("Index");
        }
    }
}
