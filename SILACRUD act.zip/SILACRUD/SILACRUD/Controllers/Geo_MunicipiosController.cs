﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using SILACRUD.Models;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.Extensions.Configuration;

namespace SILACRUD.Controllers
{
    public class Geo_MunicipiosController : Controller
    {
        private readonly IConfiguration _configuration;
        private readonly string _connectionString;

        public Geo_MunicipiosController(IConfiguration configuration)
        {
            _configuration = configuration;
            _connectionString = _configuration.GetConnectionString("DefaultConnection");
        }

        // GET: Geo_MunicipiosController
        [HttpGet]
        public ActionResult Index(string searchMunicipios = null)
        {
            DataTable dtblMunicipios = new DataTable();
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();
                using (SqlCommand sqlCmd = new SqlCommand("sp_sila_geo_municipios", sqlCon))
                {
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@tipooperacion", 4);
                    sqlCmd.Parameters.AddWithValue("@id", string.IsNullOrEmpty(searchMunicipios) ? (object)DBNull.Value : searchMunicipios);
                    sqlCmd.Parameters.AddWithValue("@refdepartamento", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@departamento", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@codigomunicipio", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@nombre", DBNull.Value);

                    SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);
                    sqlDa.Fill(dtblMunicipios);
                }
            }
            ViewData["CurrentFilter"] = searchMunicipios;
            return View(dtblMunicipios);
        }

        // GET: Geo_MunicipiosController/Details/5
        public ActionResult Details(string id)
        {
            Geo_MunicipiosModel geo_municipiosModel = new Geo_MunicipiosModel();
            DataTable dtblMunicipios = new DataTable();
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();

                SqlCommand sqlCmd = new SqlCommand("sp_sila_geo_municipios", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                sqlCmd.Parameters.AddWithValue("@tipooperacion", 2);
                sqlCmd.Parameters.AddWithValue("@id", id);
                sqlCmd.Parameters.AddWithValue("@refdepartamento", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@departamento", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@codigomunicipio", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@nombre", DBNull.Value);

                SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);
                sqlDa.Fill(dtblMunicipios);
            }
            if (dtblMunicipios.Rows.Count == 1)
            {
                geo_municipiosModel.id = dtblMunicipios.Rows[0]["id"].ToString();
                geo_municipiosModel.refdepartamento = dtblMunicipios.Rows[0]["refdepartamento"].ToString();
                geo_municipiosModel.departamento = Convert.ToInt32(dtblMunicipios.Rows[0]["departamento"].ToString());
                geo_municipiosModel.codigomunicipio = Convert.ToInt32(dtblMunicipios.Rows[0]["codigomunicipio"].ToString());
                geo_municipiosModel.nombre = dtblMunicipios.Rows[0]["nombre"].ToString();
                return View(geo_municipiosModel);
            }
            else
            {
                return RedirectToAction("Index");
            }
        }

        // GET: Geo_MunicipiosController/Create
        public ActionResult Create()
        {
            return View(new Geo_MunicipiosModel());
        }

        // POST: Geo_MunicipiosController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Geo_MunicipiosModel geo_municipiosModel)
        {
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();

                SqlCommand sqlCmd = new SqlCommand("sp_sila_geo_municipios", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;


                sqlCmd.Parameters.AddWithValue("@tipooperacion", 1);
                sqlCmd.Parameters.AddWithValue("@id", geo_municipiosModel.id ?? (object)DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@refdepartamento", geo_municipiosModel.refdepartamento ?? (object)DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@departamento", geo_municipiosModel.departamento);
                sqlCmd.Parameters.AddWithValue("@codigomunicipio", geo_municipiosModel.codigomunicipio);
                sqlCmd.Parameters.AddWithValue("@nombre", geo_municipiosModel.nombre?? (object)DBNull.Value);
                sqlCmd.ExecuteNonQuery();
            }
            return RedirectToAction("Index");
        }

        // GET: Geo_MunicipiosController/Edit/5
        public ActionResult Edit(string id)
        {
            Geo_MunicipiosModel geo_municipiosModel = new Geo_MunicipiosModel();
            DataTable dtblMunicipios = new DataTable();
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();

                SqlCommand sqlCmd = new SqlCommand("sp_sila_geo_municipios", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                sqlCmd.Parameters.AddWithValue("@tipooperacion", 2);
                sqlCmd.Parameters.AddWithValue("@id", id);
                sqlCmd.Parameters.AddWithValue("@refdepartamento", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@departamento", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@codigomunicipio", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@nombre", DBNull.Value);

                SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);
                sqlDa.Fill(dtblMunicipios);
            }
            if (dtblMunicipios.Rows.Count == 1)
            {
                geo_municipiosModel.id = dtblMunicipios.Rows[0]["id"].ToString();
                geo_municipiosModel.refdepartamento = dtblMunicipios.Rows[0]["refdepartamento"].ToString();
                geo_municipiosModel.departamento = Convert.ToInt32(dtblMunicipios.Rows[0]["departamento"].ToString());
                geo_municipiosModel.codigomunicipio = Convert.ToInt32(dtblMunicipios.Rows[0]["codigomunicipio"].ToString());
                geo_municipiosModel.nombre = dtblMunicipios.Rows[0]["nombre"].ToString();
                return View(geo_municipiosModel);
            }
            else
            {
                return RedirectToAction("Index");
            }
        }

        // POST: Geo_MunicipiosController/Edit/5
        [HttpPost]
        public ActionResult Edit(Geo_MunicipiosModel geo_municipiosModel)
        {
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();
                using (SqlCommand sqlCmd = new SqlCommand("sp_sila_geo_municipios", sqlCon))
                {
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@tipooperacion", 3);
                    sqlCmd.Parameters.AddWithValue("@id", geo_municipiosModel.id ?? (object)DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@refdepartamento", geo_municipiosModel.refdepartamento ?? (object)DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@departamento", geo_municipiosModel.departamento);
                    sqlCmd.Parameters.AddWithValue("@codigomunicipio", geo_municipiosModel.codigomunicipio);
                    sqlCmd.Parameters.AddWithValue("@nombre", geo_municipiosModel.nombre ?? (object)DBNull.Value);
                    sqlCmd.ExecuteNonQuery();
                }
            }
            return RedirectToAction("Index");
        }

        // GET: Geo_MunicipiosController/Delete/5
        [HttpGet]
        public ActionResult Delete(string id)
        {
            Geo_MunicipiosModel geo_municipiosModel = new Geo_MunicipiosModel();
            DataTable dtblMunicipios = new DataTable();
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();

                SqlCommand sqlCmd = new SqlCommand("sp_sila_geo_municipios", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                sqlCmd.Parameters.AddWithValue("@tipooperacion", 2);
                sqlCmd.Parameters.AddWithValue("@id", id);
                sqlCmd.Parameters.AddWithValue("@refdepartamento", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@departamento", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@codigomunicipio", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@nombre", DBNull.Value);

                SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);
                sqlDa.Fill(dtblMunicipios);
            }
            if (dtblMunicipios.Rows.Count == 1)
            {
                geo_municipiosModel.id = dtblMunicipios.Rows[0]["id"].ToString();
                geo_municipiosModel.refdepartamento = dtblMunicipios.Rows[0]["refdepartamento"].ToString();
                geo_municipiosModel.departamento = Convert.ToInt32(dtblMunicipios.Rows[0]["departamento"].ToString());
                geo_municipiosModel.codigomunicipio = Convert.ToInt32(dtblMunicipios.Rows[0]["codigomunicipio"].ToString());
                geo_municipiosModel.nombre = dtblMunicipios.Rows[0]["nombre"].ToString();
                return View(geo_municipiosModel);
            }
            else
            {
                return RedirectToAction("Index");
            }
        }

        // POST: Geo_MunicipiosController/Delete/5
        [HttpPost]
        public ActionResult DeleteConfirmed(string id)
        {
            try
            {
                using (SqlConnection sqlCon = new SqlConnection(_connectionString))
                {
                    sqlCon.Open();
                    using (SqlCommand sqlCmd = new SqlCommand("sp_sila_geo_municipios", sqlCon))
                    {
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.Parameters.AddWithValue("@tipooperacion", 5);
                        sqlCmd.Parameters.AddWithValue("@id", id);
                        sqlCmd.Parameters.AddWithValue("@refdepartamento", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@departamento", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@codigomunicipio", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@nombre", DBNull.Value);

                        int rowsAffected = sqlCmd.ExecuteNonQuery();

                        if (rowsAffected == 0)
                        {
                            TempData["ErrorMessage"] = "No se encontró el municipio especificado.";
                        }
                        else
                        {
                            TempData["SuccessMessage"] = "Municipio eliminado exitosamente.";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Ocurrió un error al intentar eliminar el municipio. Por favor, intente de nuevo.";
            }
            return RedirectToAction("Index");
        }
    }
}