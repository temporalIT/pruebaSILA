﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using SILACRUD.Models;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.Extensions.Configuration;

namespace SILACRUD.Controllers
{
    public class PromotorController : Controller
    {

        private readonly IConfiguration _configuration;
        private readonly string _connectionString;

        public PromotorController(IConfiguration configuration)
        {
            _configuration = configuration;
            _connectionString = _configuration.GetConnectionString("DefaultConnection");
        }


        [HttpGet]
        public ActionResult Index(float? searchPromotor = null)
        {
            DataTable dtblPromotor = new DataTable();
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();
                using (SqlCommand sqlCmd = new SqlCommand("sp_sila_promotor", sqlCon))
                {
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@tipooperacion", 4);
                    sqlCmd.Parameters.AddWithValue("@promotor", searchPromotor.HasValue ? (object)searchPromotor.Value : DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@pais", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@nombre", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@correo", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@cc", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@cco", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@tipo", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@estado", 1);

                    SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);
                    sqlDa.Fill(dtblPromotor);
                }
            }
            ViewData["CurrentFilter"] = searchPromotor;
            return View(dtblPromotor);
        }

        // GET: PromotorController/Details/5
        public ActionResult Details(float id)
        {
            PromotorModel promotorModel = new PromotorModel();
            DataTable dtblPromotor = new DataTable();
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();

                SqlCommand sqlCmd = new SqlCommand("sp_sila_promotor", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                sqlCmd.Parameters.AddWithValue("@tipooperacion", 2);
                sqlCmd.Parameters.AddWithValue("@promotor", id);
                sqlCmd.Parameters.AddWithValue("@pais", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@nombre", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@correo", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@cc", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@cco", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@tipo", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@estado", DBNull.Value);

                SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);
                sqlDa.Fill(dtblPromotor);
            }
            if (dtblPromotor.Rows.Count == 1)
            {
                promotorModel.promotor = Convert.ToInt32(dtblPromotor.Rows[0]["promotor"].ToString());
                promotorModel.pais = dtblPromotor.Rows[0]["pais"].ToString();
                promotorModel.nombre = dtblPromotor.Rows[0]["nombre"].ToString();
                promotorModel.correo = dtblPromotor.Rows[0]["correo"].ToString();
                promotorModel.cc = dtblPromotor.Rows[0]["cc"].ToString();
                promotorModel.cco = dtblPromotor.Rows[0]["cco"].ToString();
                promotorModel.tipo = dtblPromotor.Rows[0]["tipo"].ToString();
                promotorModel.estado = Convert.ToInt32(dtblPromotor.Rows[0]["estado"].ToString());
                return View(promotorModel);
            }
            else
            {
                return RedirectToAction("Index");
            }
        }

        // GET: PromotorController/Create
        public ActionResult Create()
        {

            
            return View(new PromotorModel());
        }

        // POST: PromotorController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(PromotorModel promotorModel)
        {
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();

                SqlCommand sqlCmd = new SqlCommand("sp_sila_promotor", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;


                sqlCmd.Parameters.AddWithValue("@tipooperacion", 1);
                sqlCmd.Parameters.AddWithValue("@promotor", promotorModel.promotor);
                sqlCmd.Parameters.AddWithValue("@pais", promotorModel.pais ?? (object)DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@nombre", promotorModel.nombre ?? (object)DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@correo", promotorModel.correo ?? (object)DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@cc", promotorModel.cc ?? (object)DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@cco", promotorModel.cco ?? (object)DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@tipo", promotorModel.tipo ?? (object)DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@estado", 1);
                sqlCmd.ExecuteNonQuery();

            }
            return RedirectToAction("Index");
        }


        ////////



        // GET: PromotorController/Edit/5
        public ActionResult Edit(float id)
        {
            PromotorModel promotorModel = new PromotorModel();
            DataTable dtblPromotor = new DataTable();
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();

                SqlCommand sqlCmd = new SqlCommand("sp_sila_promotor", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                sqlCmd.Parameters.AddWithValue("@tipooperacion", 2);
                sqlCmd.Parameters.AddWithValue("@promotor", id);
                sqlCmd.Parameters.AddWithValue("@pais", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@nombre", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@correo", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@cc", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@cco", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@tipo", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@estado", DBNull.Value);

                SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);
                sqlDa.Fill(dtblPromotor);
            }
            if (dtblPromotor.Rows.Count == 1)
            {
                promotorModel.promotor = Convert.ToInt32(dtblPromotor.Rows[0]["promotor"].ToString());
                promotorModel.pais = dtblPromotor.Rows[0]["pais"].ToString();
                promotorModel.nombre = dtblPromotor.Rows[0]["nombre"].ToString();
                promotorModel.correo = dtblPromotor.Rows[0]["correo"].ToString();
                promotorModel.cc = dtblPromotor.Rows[0]["cc"].ToString();
                promotorModel.cco = dtblPromotor.Rows[0]["cco"].ToString();
                promotorModel.tipo = dtblPromotor.Rows[0]["tipo"].ToString();
                promotorModel.estado = Convert.ToInt32(dtblPromotor.Rows[0]["estado"].ToString());
                return View(promotorModel);
            }
            else
            {
                return RedirectToAction("Index");
            }
        }

        // POST: PromotorController/Edit/5
        [HttpPost]
        public ActionResult Edit(PromotorModel promotorModel)
        {
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();
                using (SqlCommand sqlCmd = new SqlCommand("sp_sila_promotor", sqlCon))
                {
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@tipooperacion", 3);
                    sqlCmd.Parameters.AddWithValue("@promotor", promotorModel.promotor);
                    sqlCmd.Parameters.AddWithValue("@pais", promotorModel.pais ?? (object)DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@nombre", promotorModel.nombre ?? (object)DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@correo", promotorModel.correo ?? (object)DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@cc", promotorModel.cc ?? (object)DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@cco", promotorModel.cco ?? (object)DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@tipo", promotorModel.tipo ?? (object)DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@estado", promotorModel.estado);

                    sqlCmd.ExecuteNonQuery();
                }
            }
            return RedirectToAction("Index");
        }

        // GET: PromotorController/Delete/5
        [HttpGet]
        public ActionResult Delete(float id)
        {
            PromotorModel promotorModel = new PromotorModel();
            DataTable dtblPromotor = new DataTable();
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();

                SqlCommand sqlCmd = new SqlCommand("sp_sila_promotor", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                sqlCmd.Parameters.AddWithValue("@tipooperacion", 2);
                sqlCmd.Parameters.AddWithValue("@promotor", id);
                sqlCmd.Parameters.AddWithValue("@pais", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@nombre", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@correo", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@cc", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@cco", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@tipo", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@estado", DBNull.Value);

                SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);
                sqlDa.Fill(dtblPromotor);
            }
            if (dtblPromotor.Rows.Count == 1)
            {
                promotorModel.promotor = Convert.ToInt32(dtblPromotor.Rows[0]["promotor"].ToString());
                promotorModel.pais = dtblPromotor.Rows[0]["pais"].ToString();
                promotorModel.nombre = dtblPromotor.Rows[0]["nombre"].ToString();
                promotorModel.correo = dtblPromotor.Rows[0]["correo"].ToString();
                promotorModel.cc = dtblPromotor.Rows[0]["cc"].ToString();
                promotorModel.cco = dtblPromotor.Rows[0]["cco"].ToString();
                promotorModel.tipo = dtblPromotor.Rows[0]["tipo"].ToString();
                promotorModel.estado = Convert.ToInt32(dtblPromotor.Rows[0]["estado"].ToString());
                return View(promotorModel);
            }
            else
            {
                return RedirectToAction("Index");
            }
        }

        // POST: PromotorController/Delete/5
        [HttpPost]
        public ActionResult DeleteConfirmed(float id)
        {
            try
            {
                using (SqlConnection sqlCon = new SqlConnection(_connectionString))
                {
                    sqlCon.Open();
                    using (SqlCommand sqlCmd = new SqlCommand("sp_sila_promotor", sqlCon))
                    {
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.Parameters.AddWithValue("@tipooperacion", 5);
                        sqlCmd.Parameters.AddWithValue("@promotor", id);
                        sqlCmd.Parameters.AddWithValue("@pais", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@nombre", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@correo", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@cc", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@cco", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@tipo", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@estado", DBNull.Value);

                        int rowsAffected = sqlCmd.ExecuteNonQuery();

                        if (rowsAffected == 0)
                        {
                            TempData["ErrorMessage"] = "No se encontró el promotor especificado.";
                        }
                        else
                        {
                            TempData["SuccessMessage"] = "Estado del promotor actualizado exitosamente.";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Ocurrió un error al intentar actualizar el estado del promotor. Por favor, intente de nuevo.";
            }
            return RedirectToAction("Index");
        }
    }
}