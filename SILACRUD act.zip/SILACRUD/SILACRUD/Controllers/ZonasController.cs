﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SILACRUD.Models;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SILACRUD.Controllers
{
    public class ZonasController : Controller
    {

        private readonly IConfiguration _configuration;
        private readonly string _connectionString;

        public ZonasController(IConfiguration configuration)
        {
            _configuration = configuration;
            _connectionString = _configuration.GetConnectionString("DefaultConnection");
        }


        [HttpGet]
        public ActionResult Index(int? searchCodigo = null)
        {
            DataTable dtblZonas = new DataTable();
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();
                using (SqlCommand sqlCmd = new SqlCommand("sp_sila_zonas", sqlCon))
                {
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@tipooperacion", 4);
                    sqlCmd.Parameters.AddWithValue("@codigo", searchCodigo.HasValue ? (object)searchCodigo.Value : DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@pais", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@zonas", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@descripcion", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@promotor", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@estado", 1);  


                    SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);
                    sqlDa.Fill(dtblZonas);
                }
            }
            ViewData["CurrentFilter"] = searchCodigo;
            return View(dtblZonas);
        }


        public ActionResult Details(int id)
        {
            ZonasModel zonasModel = new ZonasModel();
            DataTable dtblZonas = new DataTable();
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();

                SqlCommand sqlCmd = new SqlCommand("sp_sila_zonas", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                sqlCmd.Parameters.AddWithValue("@tipooperacion", 2);
                sqlCmd.Parameters.AddWithValue("@codigo", id);
                sqlCmd.Parameters.AddWithValue("@pais", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@zonas", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@descripcion", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@promotor", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@estado", DBNull.Value);

                SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);
                sqlDa.Fill(dtblZonas);
            }
            if (dtblZonas.Rows.Count == 1)
            {
                zonasModel.codigo = Convert.ToInt32(dtblZonas.Rows[0]["codigo"].ToString());
                zonasModel.pais = dtblZonas.Rows[0]["pais"].ToString();
                zonasModel.zonas = dtblZonas.Rows[0]["zonas"].ToString();
                zonasModel.descripcion = dtblZonas.Rows[0]["descripcion"].ToString();
                zonasModel.promotor = Convert.ToInt32(dtblZonas.Rows[0]["promotor"].ToString());
                zonasModel.estado = Convert.ToInt32(dtblZonas.Rows[0]["estado"].ToString());
                return View(zonasModel);
            }
            else
            {
                return RedirectToAction("Index");
            }
        }



        public ActionResult Create()
        {
            return View(new ZonasModel());
        }

        // POST: ZonasController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(ZonasModel zonasModel)
        {
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();

                SqlCommand sqlCmd = new SqlCommand("sp_sila_zonas", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                sqlCmd.Parameters.AddWithValue("@tipooperacion", 1);
                sqlCmd.Parameters.AddWithValue("@codigo", zonasModel.codigo);
                sqlCmd.Parameters.AddWithValue("@pais", zonasModel.pais ?? (object)DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@zonas", zonasModel.zonas ?? (object)DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@descripcion", zonasModel.descripcion ?? (object)DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@promotor", zonasModel.promotor);
                sqlCmd.Parameters.AddWithValue("@estado", 1);
                sqlCmd.ExecuteNonQuery();

            }
            return RedirectToAction("Index");
        }

        // GET: ZonasController/Edit/5
        public ActionResult Edit(int id)
        {
            ZonasModel zonasModel = new ZonasModel();
            DataTable dtblZonas = new DataTable();
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();

                SqlCommand sqlCmd = new SqlCommand("sp_sila_zonas", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                sqlCmd.Parameters.AddWithValue("@tipooperacion", 2);
                sqlCmd.Parameters.AddWithValue("@codigo", id);
                sqlCmd.Parameters.AddWithValue("@pais", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@zonas", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@descripcion", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@promotor", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@estado", DBNull.Value);

                SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);
                sqlDa.Fill(dtblZonas);
            }
            if (dtblZonas.Rows.Count == 1)
            {
                zonasModel.codigo = Convert.ToInt32(dtblZonas.Rows[0]["codigo"].ToString());
                zonasModel.pais = dtblZonas.Rows[0]["pais"].ToString();
                zonasModel.zonas = dtblZonas.Rows[0]["zonas"].ToString();
                zonasModel.descripcion = dtblZonas.Rows[0]["descripcion"].ToString();
                zonasModel.promotor = Convert.ToInt32(dtblZonas.Rows[0]["promotor"].ToString());
                zonasModel.estado = Convert.ToInt32(dtblZonas.Rows[0]["estado"].ToString());
                return View(zonasModel);
            }
            else
            {
                return RedirectToAction("Index");
            }
        }

        // POST: ZonasController/Edit/5
        [HttpPost]
        public ActionResult Edit(ZonasModel zonasModel)
        {
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();
                using (SqlCommand sqlCmd = new SqlCommand("sp_sila_zonas", sqlCon))
                {
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@tipooperacion", 3);
                    sqlCmd.Parameters.AddWithValue("@codigo", zonasModel.codigo);
                    sqlCmd.Parameters.AddWithValue("@pais", zonasModel.pais ?? (object)DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@zonas", zonasModel.zonas ?? (object)DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@descripcion", zonasModel.descripcion ?? (object)DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@promotor", zonasModel.promotor);
                    sqlCmd.Parameters.AddWithValue("@estado", zonasModel.estado);

                    sqlCmd.ExecuteNonQuery();
                }
            }
            return RedirectToAction("Index");
        }

        // GET: ZonasController/Delete/5
        [HttpGet]
        public ActionResult Delete(float id)
        {
            ZonasModel zonasModel = new ZonasModel();
            DataTable dtblZonas = new DataTable();
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();

                SqlCommand sqlCmd = new SqlCommand("sp_sila_zonas", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                sqlCmd.Parameters.AddWithValue("@tipooperacion", 2);
                sqlCmd.Parameters.AddWithValue("@codigo", id);
                sqlCmd.Parameters.AddWithValue("@pais", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@zonas", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@descripcion", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@promotor", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@estado", DBNull.Value);

                SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);
                sqlDa.Fill(dtblZonas);
            }
            if (dtblZonas.Rows.Count == 1)
            {
                zonasModel.codigo = Convert.ToInt32(dtblZonas.Rows[0]["codigo"].ToString());
                zonasModel.pais = dtblZonas.Rows[0]["pais"].ToString();
                zonasModel.zonas = dtblZonas.Rows[0]["zonas"].ToString();
                zonasModel.descripcion = dtblZonas.Rows[0]["descripcion"].ToString();
                zonasModel.promotor = Convert.ToInt32(dtblZonas.Rows[0]["promotor"].ToString());
                zonasModel.estado = Convert.ToInt32(dtblZonas.Rows[0]["estado"].ToString());
                return View(zonasModel);
            }
            else
            {
                return RedirectToAction("Index");
            }
        }

        // POST: ZonasController/Delete/5
        [HttpPost]
        public ActionResult DeleteConfirmed(int id)
        {
            try
            {
                using (SqlConnection sqlCon = new SqlConnection(_connectionString))
                {
                    sqlCon.Open();
                    using (SqlCommand sqlCmd = new SqlCommand("sp_sila_zonas", sqlCon))
                    {
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.Parameters.AddWithValue("@tipooperacion", 5);
                        sqlCmd.Parameters.AddWithValue("@codigo", id);
                        sqlCmd.Parameters.AddWithValue("@pais", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@zonas", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@descripcion", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@promotor", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@estado", DBNull.Value);

                        int rowsAffected = sqlCmd.ExecuteNonQuery();

                        if (rowsAffected == 0)
                        {
                            TempData["ErrorMessage"] = "No se encontró la zona especificado.";
                        }
                        else
                        {
                            TempData["SuccessMessage"] = "Estado de la zona actualizada exitosamente.";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Ocurrió un error al intentar actualizar el estado de la zona. Por favor, intente de nuevo.";
            }
            return RedirectToAction("Index");
        }
    }
}