﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using SILACRUD.Models;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.Extensions.Configuration;

namespace SILACRUD.Controllers
{
    public class ZonasdetalleController : Controller
    {

        private readonly IConfiguration _configuration;
        private readonly string _connectionString;

        public ZonasdetalleController(IConfiguration configuration)
        {
            _configuration = configuration;
            _connectionString = _configuration.GetConnectionString("DefaultConnection");
        }


        // GET: ZonasdetalleController
        [HttpGet]
        public ActionResult Index(int? searchID = null)
        {
            DataTable dtblZonasdetalle = new DataTable();
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();
                using (SqlCommand sqlCmd = new SqlCommand("sp_sila_zonas_detalle", sqlCon))
                {
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@tipooperacion", 4);
                    sqlCmd.Parameters.AddWithValue("@id", searchID.HasValue ? (object)searchID.Value : DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@zona", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@cliente", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@estado", 1);

                    SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);
                    sqlDa.Fill(dtblZonasdetalle);
                }
            }
            ViewData["CurrentFilter"] = searchID;
            return View(dtblZonasdetalle);
        }

        // GET: ZonasdetalleController/Details/5
        public ActionResult Details(int id)
        {
            ZonasdetalleModel zonasdetalleModel = new ZonasdetalleModel();
            DataTable dtblZonasdetalle = new DataTable();
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();

                SqlCommand sqlCmd = new SqlCommand("sp_sila_zonas_detalle", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                sqlCmd.Parameters.AddWithValue("@tipooperacion", 2);
                sqlCmd.Parameters.AddWithValue("@id", id);
                sqlCmd.Parameters.AddWithValue("@zona", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@cliente", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@estado", DBNull.Value);

                SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);
                sqlDa.Fill(dtblZonasdetalle);
            }
            if (dtblZonasdetalle.Rows.Count == 1)
            {
                zonasdetalleModel.id = Convert.ToInt32(dtblZonasdetalle.Rows[0]["id"].ToString());
                zonasdetalleModel.zona = Convert.ToInt32(dtblZonasdetalle.Rows[0]["zona"].ToString());
                zonasdetalleModel.cliente = Convert.ToInt32(dtblZonasdetalle.Rows[0]["cliente"].ToString());
                zonasdetalleModel.estado = Convert.ToInt32(dtblZonasdetalle.Rows[0]["estado"].ToString());
                return View(zonasdetalleModel);
            }
            else
            {
                return RedirectToAction("Index");
            }
        }

        // GET: ZonasdetalleController/Create
        public ActionResult Create()
        {
            return View(new ZonasdetalleModel());
        }

        // POST: ZonasdetalleController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(ZonasdetalleModel zonasdetalleModel)
        {
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();

                SqlCommand sqlCmd = new SqlCommand("sp_sila_zonas_detalle", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                sqlCmd.Parameters.AddWithValue("@tipooperacion", 1);
                sqlCmd.Parameters.AddWithValue("@id", zonasdetalleModel.id);
                sqlCmd.Parameters.AddWithValue("@zona", zonasdetalleModel.zona);
                sqlCmd.Parameters.AddWithValue("@cliente", zonasdetalleModel.cliente);
                sqlCmd.Parameters.AddWithValue("@estado", 1);
                sqlCmd.ExecuteNonQuery();

            }
            return RedirectToAction("Index");
        }

        // GET: ZonasdetalleController/Edit/5
        public ActionResult Edit(int id)
        {
            ZonasdetalleModel zonasdetalleModel = new ZonasdetalleModel();
            DataTable dtblZonasdetalle = new DataTable();
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();

                SqlCommand sqlCmd = new SqlCommand("sp_sila_zonas_detalle", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                sqlCmd.Parameters.AddWithValue("@tipooperacion", 2);
                sqlCmd.Parameters.AddWithValue("@id", id);
                sqlCmd.Parameters.AddWithValue("@zona", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@cliente", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@estado", DBNull.Value);

                SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);
                sqlDa.Fill(dtblZonasdetalle);
            }
            if (dtblZonasdetalle.Rows.Count == 1)
            {
                zonasdetalleModel.id = Convert.ToInt32(dtblZonasdetalle.Rows[0]["id"].ToString());
                zonasdetalleModel.zona = Convert.ToInt32(dtblZonasdetalle.Rows[0]["zona"].ToString());
                zonasdetalleModel.cliente = Convert.ToInt32(dtblZonasdetalle.Rows[0]["cliente"].ToString());
                zonasdetalleModel.estado = Convert.ToInt32(dtblZonasdetalle.Rows[0]["estado"].ToString());
                return View(zonasdetalleModel);
            }
            else
            {
                return RedirectToAction("Index");
            }
        }

        // POST: ZonasdetalleController/Edit/5
        [HttpPost]
        public ActionResult Edit(ZonasdetalleModel zonasdetalleModel)
        {
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();
                using (SqlCommand sqlCmd = new SqlCommand("sp_sila_zonas_detalle", sqlCon))
                {
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@tipooperacion", 3);
                    sqlCmd.Parameters.AddWithValue("@id", zonasdetalleModel.id);
                    sqlCmd.Parameters.AddWithValue("@zona", zonasdetalleModel.zona);
                    sqlCmd.Parameters.AddWithValue("@cliente", zonasdetalleModel.cliente);
                    sqlCmd.Parameters.AddWithValue("@estado", zonasdetalleModel.estado);

                    sqlCmd.ExecuteNonQuery();
                }
            }
            return RedirectToAction("Index");
        }

        // GET: ZonasdetalleController/Delete/5
        [HttpGet]
        public ActionResult Delete(int id)
        {
            ZonasdetalleModel zonasdetalleModel = new ZonasdetalleModel();
            DataTable dtblZonasdetalle = new DataTable();
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();

                SqlCommand sqlCmd = new SqlCommand("sp_sila_zonas_detalle", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                sqlCmd.Parameters.AddWithValue("@tipooperacion", 2);
                sqlCmd.Parameters.AddWithValue("@id", id);
                sqlCmd.Parameters.AddWithValue("@zona", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@cliente", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@estado", DBNull.Value);

                SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);
                sqlDa.Fill(dtblZonasdetalle);
            }
            if (dtblZonasdetalle.Rows.Count == 1)
            {
                zonasdetalleModel.id = Convert.ToInt32(dtblZonasdetalle.Rows[0]["id"].ToString());
                zonasdetalleModel.zona = Convert.ToInt32(dtblZonasdetalle.Rows[0]["zona"].ToString());
                zonasdetalleModel.cliente = Convert.ToInt32(dtblZonasdetalle.Rows[0]["cliente"].ToString());
                zonasdetalleModel.estado = Convert.ToInt32(dtblZonasdetalle.Rows[0]["estado"].ToString());
                return View(zonasdetalleModel);
            }
            else
            {
                return RedirectToAction("Index");
            }
        }

        // POST: ZonasdetalleController/Delete/5
        [HttpPost]
        public ActionResult DeleteConfirmed(int id)
        {
            try
            {
                using (SqlConnection sqlCon = new SqlConnection(_connectionString))
                {
                    sqlCon.Open();
                    using (SqlCommand sqlCmd = new SqlCommand("sp_sila_zonas_detalle", sqlCon))
                    {
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.Parameters.AddWithValue("@tipooperacion", 5);
                        sqlCmd.Parameters.AddWithValue("@id", id);
                        sqlCmd.Parameters.AddWithValue("@zona", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@cliente", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@estado", DBNull.Value);

                        int rowsAffected = sqlCmd.ExecuteNonQuery();

                        if (rowsAffected == 0)
                        {
                            TempData["ErrorMessage"] = "No se encontró la zona detalle especificada.";
                        }
                        else
                        {
                            TempData["SuccessMessage"] = "Estado de la zona detalle actualizada exitosamente.";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Ocurrió un error al intentar actualizar el estado de la zona detalle. Por favor, intente de nuevo.";
            }
            return RedirectToAction("Index");
        }
    }
}