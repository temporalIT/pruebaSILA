﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using SILACRUD.Models;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.Extensions.Configuration;

namespace SILACRUD.Controllers
{
    public class DistribuidorController : Controller
    {
        private readonly IConfiguration _configuration;
        private readonly string _connectionString;

        public DistribuidorController(IConfiguration configuration)
        {
            _configuration = configuration;
            _connectionString = _configuration.GetConnectionString("DefaultConnection");
        }

        // GET: DistribuidorController
        [HttpGet]
        public ActionResult Index(int? searchDistribuidor = null)
        {
            DataTable dtblDistribuidor = new DataTable();
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();
                using (SqlCommand sqlCmd = new SqlCommand("sp_sila_distribuidor", sqlCon))
                {
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@tipooperacion", 4);
                    sqlCmd.Parameters.AddWithValue("@Distribuidor", searchDistribuidor.HasValue ? (object)searchDistribuidor.Value : DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@Pais", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@Nombre", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@Direccion", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@Tel", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@Fax", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@Contacto", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@email", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@Margen", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@Descuento_Aut", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@Nivel_Inventario", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@DistInventario", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@Descuento_Aut_Max", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@estado", 1);
                    sqlCmd.Parameters.AddWithValue("@tipo", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@ALIAS", DBNull.Value);

                    SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);
                    sqlDa.Fill(dtblDistribuidor);
                }
            }
            ViewData["CurrentFilter"] = searchDistribuidor;
            return View(dtblDistribuidor);
        }

        // GET: DistribuidorController/Details/5
        public ActionResult Details(int id)
        {
            DistribuidorModel distribuidorModel = new DistribuidorModel();
            DataTable dtblDistribuidor = new DataTable();
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();

                SqlCommand sqlCmd = new SqlCommand("sp_sila_distribuidor", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                sqlCmd.Parameters.AddWithValue("@tipooperacion", 2);
                sqlCmd.Parameters.AddWithValue("@Distribuidor", id);
                sqlCmd.Parameters.AddWithValue("@Pais", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@Nombre", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@Direccion", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@Tel", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@Fax", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@Contacto", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@email", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@Margen", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@Descuento_Aut", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@Nivel_Inventario", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@DistInventario", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@Descuento_Aut_Max", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@estado", 1);
                sqlCmd.Parameters.AddWithValue("@tipo", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@ALIAS", DBNull.Value);

                SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);
                sqlDa.Fill(dtblDistribuidor);
            }
            if (dtblDistribuidor.Rows.Count == 1)
            {
                distribuidorModel.Distribuidor = Convert.ToInt32(dtblDistribuidor.Rows[0]["Distribuidor"].ToString());
                distribuidorModel.Pais = dtblDistribuidor.Rows[0]["Pais"].ToString();
                distribuidorModel.Nombre = dtblDistribuidor.Rows[0]["Nombre"].ToString();
                distribuidorModel.Direccion = dtblDistribuidor.Rows[0]["Direccion"].ToString();
                distribuidorModel.Tel = dtblDistribuidor.Rows[0]["Tel"].ToString();
                distribuidorModel.Fax = dtblDistribuidor.Rows[0]["Fax"].ToString();
                distribuidorModel.Contacto = dtblDistribuidor.Rows[0]["Contacto"].ToString();
                distribuidorModel.email = dtblDistribuidor.Rows[0]["email"].ToString();
                distribuidorModel.Margen = Convert.ToInt32(dtblDistribuidor.Rows[0]["Margen"].ToString());
                distribuidorModel.Descuento_Aut = Convert.ToInt32(dtblDistribuidor.Rows[0]["Descuento_Aut"].ToString());
                distribuidorModel.Nivel_Inventario = Convert.ToInt32(dtblDistribuidor.Rows[0]["Nivel_Inventario"].ToString());
                distribuidorModel.DistInventario = Convert.ToInt32(dtblDistribuidor.Rows[0]["DistInventario"].ToString());
                distribuidorModel.Descuento_Aut_Max = Convert.ToInt32(dtblDistribuidor.Rows[0]["Descuento_Aut_Max"].ToString());
                distribuidorModel.estado = Convert.ToInt32(dtblDistribuidor.Rows[0]["estado"].ToString());
                distribuidorModel.tipo = Convert.ToInt32(dtblDistribuidor.Rows[0]["tipo"].ToString());
                distribuidorModel.ALIAS = dtblDistribuidor.Rows[0]["ALIAS"].ToString();
                return View(distribuidorModel);
            }
            else
            {
                return RedirectToAction("Index");
            }
        }

        // GET: DistribuidorController/Create
        public ActionResult Create()
        {
            return View(new DistribuidorModel());
        }

        // POST: DistribuidorController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(DistribuidorModel distribuidorModel)
        {
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();

                SqlCommand sqlCmd = new SqlCommand("sp_sila_distribuidor", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;


                sqlCmd.Parameters.AddWithValue("@tipooperacion", 1);
                sqlCmd.Parameters.AddWithValue("@Distribuidor", distribuidorModel.Distribuidor);
                sqlCmd.Parameters.AddWithValue("@Pais", distribuidorModel.Pais ?? (object)DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@Nombre", distribuidorModel.Nombre ?? (object)DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@Direccion", distribuidorModel.Direccion ?? (object)DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@Tel", distribuidorModel.Tel ?? (object)DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@Fax", distribuidorModel.Fax ?? (object)DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@Contacto", distribuidorModel.Contacto ?? (object)DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@email", distribuidorModel.email ?? (object)DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@Margen", distribuidorModel.Margen);
                sqlCmd.Parameters.AddWithValue("@Descuento_Aut", distribuidorModel.Descuento_Aut);
                sqlCmd.Parameters.AddWithValue("@Nivel_Inventario", distribuidorModel.Nivel_Inventario);
                sqlCmd.Parameters.AddWithValue("@DistInventario", distribuidorModel.DistInventario);
                sqlCmd.Parameters.AddWithValue("@Descuento_Aut_Max", distribuidorModel.Descuento_Aut_Max);
                sqlCmd.Parameters.AddWithValue("@estado", 1);
                sqlCmd.Parameters.AddWithValue("@tipo", distribuidorModel.tipo);
                sqlCmd.Parameters.AddWithValue("@ALIAS", distribuidorModel.ALIAS ?? (object)DBNull.Value);
                sqlCmd.ExecuteNonQuery();

            }
            return RedirectToAction("Index");
        }

        // GET: DistribuidorController/Edit/5
        public ActionResult Edit(int id)
        {
            DistribuidorModel distribuidorModel = new DistribuidorModel();
            DataTable dtblDistribuidor = new DataTable();
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();

                SqlCommand sqlCmd = new SqlCommand("sp_sila_distribuidor", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                sqlCmd.Parameters.AddWithValue("@tipooperacion", 2);
                sqlCmd.Parameters.AddWithValue("@Distribuidor", id);
                sqlCmd.Parameters.AddWithValue("@Pais", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@Nombre", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@Direccion", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@Tel", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@Fax", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@Contacto", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@email", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@Margen", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@Descuento_Aut", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@Nivel_Inventario", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@DistInventario", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@Descuento_Aut_Max", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@estado", 1);
                sqlCmd.Parameters.AddWithValue("@tipo", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@ALIAS", DBNull.Value);

                SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);
                sqlDa.Fill(dtblDistribuidor);
            }
            if (dtblDistribuidor.Rows.Count == 1)
            {
                distribuidorModel.Distribuidor = Convert.ToInt32(dtblDistribuidor.Rows[0]["Distribuidor"].ToString());
                distribuidorModel.Pais = dtblDistribuidor.Rows[0]["Pais"].ToString();
                distribuidorModel.Nombre = dtblDistribuidor.Rows[0]["Nombre"].ToString();
                distribuidorModel.Direccion = dtblDistribuidor.Rows[0]["Direccion"].ToString();
                distribuidorModel.Tel = dtblDistribuidor.Rows[0]["Tel"].ToString();
                distribuidorModel.Fax = dtblDistribuidor.Rows[0]["Fax"].ToString();
                distribuidorModel.Contacto = dtblDistribuidor.Rows[0]["Contacto"].ToString();
                distribuidorModel.email = dtblDistribuidor.Rows[0]["email"].ToString();
                distribuidorModel.Margen = Convert.ToInt32(dtblDistribuidor.Rows[0]["Margen"].ToString());
                distribuidorModel.Descuento_Aut = Convert.ToInt32(dtblDistribuidor.Rows[0]["Descuento_Aut"].ToString());
                distribuidorModel.Nivel_Inventario = Convert.ToInt32(dtblDistribuidor.Rows[0]["Nivel_Inventario"].ToString());
                distribuidorModel.DistInventario = Convert.ToInt32(dtblDistribuidor.Rows[0]["DistInventario"].ToString());
                distribuidorModel.Descuento_Aut_Max = Convert.ToInt32(dtblDistribuidor.Rows[0]["Descuento_Aut_Max"].ToString());
                distribuidorModel.estado = Convert.ToInt32(dtblDistribuidor.Rows[0]["estado"].ToString());
                distribuidorModel.tipo = Convert.ToInt32(dtblDistribuidor.Rows[0]["tipo"].ToString());
                distribuidorModel.ALIAS = dtblDistribuidor.Rows[0]["ALIAS"].ToString();
                return View(distribuidorModel);
            }
            else
            {
                return RedirectToAction("Index");
            }
        }

        // POST: DistribuidorController/Edit/5
        [HttpPost]
        public ActionResult Edit(DistribuidorModel distribuidorModel)
        {
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();
                using (SqlCommand sqlCmd = new SqlCommand("sp_sila_distribuidor", sqlCon))
                {
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@tipooperacion", 3);
                    sqlCmd.Parameters.AddWithValue("@Distribuidor", distribuidorModel.Distribuidor);
                    sqlCmd.Parameters.AddWithValue("@Pais", distribuidorModel.Pais ?? (object)DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@Nombre", distribuidorModel.Nombre ?? (object)DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@Direccion", distribuidorModel.Direccion ?? (object)DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@Tel", distribuidorModel.Tel ?? (object)DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@Fax", distribuidorModel.Fax ?? (object)DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@Contacto", distribuidorModel.Contacto ?? (object)DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@email", distribuidorModel.email ?? (object)DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@Margen", distribuidorModel.Margen);
                    sqlCmd.Parameters.AddWithValue("@Descuento_Aut", distribuidorModel.Descuento_Aut);
                    sqlCmd.Parameters.AddWithValue("@Nivel_Inventario", distribuidorModel.Nivel_Inventario);
                    sqlCmd.Parameters.AddWithValue("@DistInventario", distribuidorModel.DistInventario);
                    sqlCmd.Parameters.AddWithValue("@Descuento_Aut_Max", distribuidorModel.Descuento_Aut_Max);
                    sqlCmd.Parameters.AddWithValue("@estado", 1);
                    sqlCmd.Parameters.AddWithValue("@tipo", distribuidorModel.tipo);
                    sqlCmd.Parameters.AddWithValue("@ALIAS", distribuidorModel.ALIAS ?? (object)DBNull.Value);
                    sqlCmd.ExecuteNonQuery();
                }
            }
            return RedirectToAction("Index");
        }

        // GET: DistribuidorController/Delete/5
        [HttpGet]
        public ActionResult Delete(int id)
        {
            DistribuidorModel distribuidorModel = new DistribuidorModel();
            DataTable dtblDistribuidor = new DataTable();
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();

                SqlCommand sqlCmd = new SqlCommand("sp_sila_distribuidor", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                sqlCmd.Parameters.AddWithValue("@tipooperacion", 2);
                sqlCmd.Parameters.AddWithValue("@Distribuidor", id);
                sqlCmd.Parameters.AddWithValue("@Pais", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@Nombre", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@Direccion", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@Tel", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@Fax", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@Contacto", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@email", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@Margen", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@Descuento_Aut", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@Nivel_Inventario", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@DistInventario", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@Descuento_Aut_Max", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@estado", 1);
                sqlCmd.Parameters.AddWithValue("@tipo", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@ALIAS", DBNull.Value);

                SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);
                sqlDa.Fill(dtblDistribuidor);
            }
            if (dtblDistribuidor.Rows.Count == 1)
            {
                distribuidorModel.Distribuidor = Convert.ToInt32(dtblDistribuidor.Rows[0]["Distribuidor"].ToString());
                distribuidorModel.Pais = dtblDistribuidor.Rows[0]["Pais"].ToString();
                distribuidorModel.Nombre = dtblDistribuidor.Rows[0]["Nombre"].ToString();
                distribuidorModel.Direccion = dtblDistribuidor.Rows[0]["Direccion"].ToString();
                distribuidorModel.Tel = dtblDistribuidor.Rows[0]["Tel"].ToString();
                distribuidorModel.Fax = dtblDistribuidor.Rows[0]["Fax"].ToString();
                distribuidorModel.Contacto = dtblDistribuidor.Rows[0]["Contacto"].ToString();
                distribuidorModel.email = dtblDistribuidor.Rows[0]["email"].ToString();
                distribuidorModel.Margen = Convert.ToInt32(dtblDistribuidor.Rows[0]["Margen"].ToString());
                distribuidorModel.Descuento_Aut = Convert.ToInt32(dtblDistribuidor.Rows[0]["Descuento_Aut"].ToString());
                distribuidorModel.Nivel_Inventario = Convert.ToInt32(dtblDistribuidor.Rows[0]["Nivel_Inventario"].ToString());
                distribuidorModel.DistInventario = Convert.ToInt32(dtblDistribuidor.Rows[0]["DistInventario"].ToString());
                distribuidorModel.Descuento_Aut_Max = Convert.ToInt32(dtblDistribuidor.Rows[0]["Descuento_Aut_Max"].ToString());
                distribuidorModel.estado = Convert.ToInt32(dtblDistribuidor.Rows[0]["estado"].ToString());
                distribuidorModel.tipo = Convert.ToInt32(dtblDistribuidor.Rows[0]["tipo"].ToString());
                distribuidorModel.ALIAS = dtblDistribuidor.Rows[0]["ALIAS"].ToString();
                return View(distribuidorModel);
            }
            else
            {
                return RedirectToAction("Index");
            }
        }

        // POST: DistribuidorController/Delete/5
        [HttpPost]
        public ActionResult DeleteConfirmed(int id)
        {
            try
            {
                using (SqlConnection sqlCon = new SqlConnection(_connectionString))
                {
                    sqlCon.Open();
                    using (SqlCommand sqlCmd = new SqlCommand("sp_sila_distribuidor", sqlCon))
                    {
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.Parameters.AddWithValue("@tipooperacion", 5);
                        sqlCmd.Parameters.AddWithValue("@Distribuidor", id);
                        sqlCmd.Parameters.AddWithValue("@Pais", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@Nombre", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@Direccion", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@Tel", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@Fax", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@Contacto", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@email", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@Margen", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@Descuento_Aut", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@Nivel_Inventario", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@DistInventario", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@Descuento_Aut_Max", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@estado", 1);
                        sqlCmd.Parameters.AddWithValue("@tipo", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@ALIAS", DBNull.Value);

                        int rowsAffected = sqlCmd.ExecuteNonQuery();

                        if (rowsAffected == 0)
                        {
                            TempData["ErrorMessage"] = "No se encontró el distribuidor especificado.";
                        }
                        else
                        {
                            TempData["SuccessMessage"] = "Estado del distribuidor actualizado exitosamente.";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Ocurrió un error al intentar actualizar el estado del distribuidor. Por favor, intente de nuevo.";
            }
            return RedirectToAction("Index");
        }
    }
}