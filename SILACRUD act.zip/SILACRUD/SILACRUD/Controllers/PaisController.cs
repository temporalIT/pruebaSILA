﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SILACRUD.Models;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.Extensions.Configuration;

namespace SILACRUD.Controllers
{
    public class PaisController : Controller
    {

        private readonly IConfiguration _configuration;
        private readonly string _connectionString;

        public PaisController(IConfiguration configuration)
        {
            _configuration = configuration;
            _connectionString = _configuration.GetConnectionString("DefaultConnection");
        }


        [HttpGet]
        public ActionResult Index(string searchString = "")
        {
            DataTable dtblPais = new DataTable();
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();
                using (SqlCommand sqlCmd = new SqlCommand("sp_sila_pais", sqlCon))
                {
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@tipooperacion", 4);
                    sqlCmd.Parameters.AddWithValue("@pais", string.IsNullOrEmpty(searchString) ? (object)DBNull.Value : searchString);
                    sqlCmd.Parameters.AddWithValue("@nombre", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@alias", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@zona", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@coordinador", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@estado", 1);  // Solo los que tienen estado igual a 1

                    SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);
                    sqlDa.Fill(dtblPais);
                }
            }
            ViewData["CurrentFilter"] = searchString;
            return View(dtblPais);
        }

        // GET: PaisController/Details/5
        public ActionResult Details(string id)
        {
            PaisModel paisModel = new PaisModel();
            DataTable dtblPais = new DataTable();
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();

                SqlCommand sqlCmd = new SqlCommand("sp_sila_pais", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                sqlCmd.Parameters.AddWithValue("@tipooperacion", 2);
                sqlCmd.Parameters.AddWithValue("@pais", id);
                sqlCmd.Parameters.AddWithValue("@nombre", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@alias", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@zona", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@coordinador", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@estado", DBNull.Value);

                SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);
                sqlDa.Fill(dtblPais);
            }
            if (dtblPais.Rows.Count == 1)
            {
                paisModel.pais = dtblPais.Rows[0]["pais"].ToString();
                paisModel.nombre = dtblPais.Rows[0]["nombre"].ToString();
                paisModel.alias = dtblPais.Rows[0]["alias"].ToString();
                paisModel.zona = dtblPais.Rows[0]["zona"].ToString();
                paisModel.coordinador = dtblPais.Rows[0]["coordinador"].ToString();
                paisModel.estado = Convert.ToInt32(dtblPais.Rows[0]["estado"].ToString());
                return View(paisModel);
            }
            else
            {
                return RedirectToAction("Index");
            }
        }

        // GET: PaisController/Create
        [HttpGet]
        public ActionResult Create()
        {
            return View(new PaisModel());
        }

        // POST: PaisController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(PaisModel paisModel)
        {
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();

                SqlCommand sqlCmd = new SqlCommand("sp_sila_pais", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;


                sqlCmd.Parameters.AddWithValue("@tipooperacion", 1);
                sqlCmd.Parameters.AddWithValue("@pais", paisModel.pais);
                sqlCmd.Parameters.AddWithValue("@nombre", paisModel.nombre ?? (object)DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@alias", paisModel.alias ?? (object)DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@zona", paisModel.zona ?? (object)DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@coordinador", paisModel.coordinador ?? (object)DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@estado", 1);
                sqlCmd.ExecuteNonQuery();

            }
            return RedirectToAction("Index");
        }

        // GET: PaisController/Edit/5
        public ActionResult Edit(string id)
        {
            PaisModel paisModel = new PaisModel();
            DataTable dtblPais = new DataTable();
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();

                SqlCommand sqlCmd = new SqlCommand("sp_sila_pais", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                sqlCmd.Parameters.AddWithValue("@tipooperacion", 2);
                sqlCmd.Parameters.AddWithValue("@pais", id);
                sqlCmd.Parameters.AddWithValue("@nombre", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@alias", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@zona", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@coordinador", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@estado", DBNull.Value);

                SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);
                sqlDa.Fill(dtblPais);
            }
            if (dtblPais.Rows.Count == 1)
            {
                paisModel.pais = dtblPais.Rows[0]["pais"].ToString();
                paisModel.nombre = dtblPais.Rows[0]["nombre"].ToString();
                paisModel.alias = dtblPais.Rows[0]["alias"].ToString();
                paisModel.zona = dtblPais.Rows[0]["zona"].ToString();
                paisModel.coordinador = dtblPais.Rows[0]["coordinador"].ToString();
                paisModel.estado = Convert.ToInt32(dtblPais.Rows[0]["estado"].ToString());
                return View(paisModel);
            }
            else
            {
                return RedirectToAction("Index");
            }
        }

        // POST: PaisController/Edit/5
        [HttpPost]
        public ActionResult Edit(PaisModel paisModel)
        {
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();
                using (SqlCommand sqlCmd = new SqlCommand("sp_sila_pais", sqlCon))
                {
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@tipooperacion", 3); // 3 para actualizar
                    sqlCmd.Parameters.AddWithValue("@pais", paisModel.pais);
                    sqlCmd.Parameters.AddWithValue("@nombre", paisModel.nombre ?? (object)DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@alias", paisModel.alias ?? (object)DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@zona", paisModel.zona ?? (object)DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@coordinador", paisModel.coordinador ?? (object)DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@estado", paisModel.estado);

                    sqlCmd.ExecuteNonQuery();
                }
            }
            return RedirectToAction("Index");
        }

        // GET: PaisController/Delete/5
        [HttpGet]
        public ActionResult Delete(string id)
        {
            PaisModel paisModel = new PaisModel();
            DataTable dtblPais = new DataTable();
            using (SqlConnection sqlCon = new SqlConnection(_connectionString))
            {
                sqlCon.Open();

                SqlCommand sqlCmd = new SqlCommand("sp_sila_pais", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                sqlCmd.Parameters.AddWithValue("@tipooperacion", 2);
                sqlCmd.Parameters.AddWithValue("@pais", id);
                sqlCmd.Parameters.AddWithValue("@nombre", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@alias", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@zona", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@coordinador", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@estado", DBNull.Value);

                SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);
                sqlDa.Fill(dtblPais);
            }
            if (dtblPais.Rows.Count == 1)
            {
                paisModel.pais = dtblPais.Rows[0]["pais"].ToString();
                paisModel.nombre = dtblPais.Rows[0]["nombre"].ToString();
                paisModel.alias = dtblPais.Rows[0]["alias"].ToString();
                paisModel.zona = dtblPais.Rows[0]["zona"].ToString();
                paisModel.coordinador = dtblPais.Rows[0]["coordinador"].ToString();
                paisModel.estado = Convert.ToInt32(dtblPais.Rows[0]["estado"].ToString());
                return View(paisModel);
            }
            else
            {
                return RedirectToAction("Index");
            }
        }

        // POST: PaisController/Delete/5
        [HttpPost]
        public ActionResult DeleteConfirmed(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                return RedirectToAction("Index");
            }

            try
            {
                using (SqlConnection sqlCon = new SqlConnection(_connectionString))
                {
                    sqlCon.Open();
                    using (SqlCommand sqlCmd = new SqlCommand("sp_sila_pais", sqlCon))
                    {
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.Parameters.AddWithValue("@tipooperacion", 5);
                        sqlCmd.Parameters.AddWithValue("@pais", id);
                        sqlCmd.Parameters.AddWithValue("@nombre", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@alias", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@zona", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@coordinador", DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@estado", DBNull.Value);

                        int rowsAffected = sqlCmd.ExecuteNonQuery();

                        if (rowsAffected == 0)
                        {
                            TempData["ErrorMessage"] = "No se encontró el país especificado.";
                        }
                        else
                        {
                            TempData["SuccessMessage"] = "Estado del país actualizado exitosamente.";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Ocurrió un error al intentar actualizar el estado del país. Por favor, intente de nuevo.";
            }
            return RedirectToAction("Index");
        }
    }
}
