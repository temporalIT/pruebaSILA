﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace SILACRUD.Models
{
    public class ClientesModel
    {
        [DisplayName("Codigo Cliente")]
        [Column(TypeName = "decimal(13, 0)")]
        public decimal? codigo { get; set; } = null!;

        [DisplayName("Pais")]
        public string pais { get; set; }

        [DisplayName("Canal")]
        public int canal { get; set; }

        [DisplayName("Nombre Comercial")]
        public string nombre_comercial { get; set; }

        [DisplayName("Nombre Lasante")]
        public string nombre_lasante { get; set; }

        [DisplayName("Tipo Cliente")]
        public int tipo_cliente { get; set; }

        [DisplayName("Dirección")]
        [Column(TypeName = "TEXT")]
        public string direccion { get; set; }

        [DisplayName("Departamento")]
        public int departamento { get; set; }

        [DisplayName("Municipio")]
        public int municipio { get; set; }

        [DisplayName("Contacto")]
        public string contacto { get; set; }

        [DisplayName("Telefono")]
        public string telefono { get; set; }

        [DisplayName("Sitio Web")]
        public string sitioweb { get; set; }

        [DisplayName("Promotor")]
        public float promotor { get; set; }

        [DisplayName("Estado")]
        public int estado { get; set; }

        [DisplayName("Referencia")]
        public string referencia { get; set; }

    }
}
