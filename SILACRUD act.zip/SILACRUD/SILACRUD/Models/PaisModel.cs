﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace SILACRUD.Models
{
    public class PaisModel
    {
        [DisplayName("País")]
        public string pais { get; set; } = null!;

        [DisplayName("Nombre")]
        public string nombre { get; set; }

        [DisplayName("Alias")]
        public string alias { get; set; }

        [DisplayName("Zona")]
        public string zona { get; set; }

        [DisplayName("Coordinador")]
        public string coordinador { get; set; }

        [DisplayName("Estado")]
        public int estado { get; set; }
    }
}
