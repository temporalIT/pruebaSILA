﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SILACRUD.Models
{
    public class Geo_DepartamentosModel
    {
        [DisplayName("Departamento")]
        public string id { get; set; } = null!;

        [DisplayName("Pais")]
        public string pais { get; set; } = null!;

        [DisplayName("Codigo")]
        public int? codigo { get; set; } = null!;

        [DisplayName("Nombre")]
        public string nombre { get; set; }

    }
}
