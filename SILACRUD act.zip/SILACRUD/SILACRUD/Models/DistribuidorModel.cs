﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SILACRUD.Models
{
    public class DistribuidorModel
    {
        [DisplayName("No. Distribuidor")]
        public int? Distribuidor { get; set; } = null!;

        [DisplayName("Pais")]
        public string Pais { get; set; } = null!;

        [DisplayName("Nombre")]
        public string Nombre { get; set; } = null!;

        [DisplayName("Dirección")]
        [Column(TypeName = "TEXT")]
        public string Direccion { get; set; }

        [DisplayName("Teléfono")]
        public string Tel { get; set; }

        [DisplayName("Fax")]
        public string Fax { get; set; }

        [DisplayName("Contacto")]
        public string Contacto { get; set; }

        [DisplayName("Email")]
        public string email { get; set; }

        [DisplayName("Margen")]
        public float Margen { get; set; }        

        [DisplayName("Descuento Autorizado")]
        public float Descuento_Aut { get; set; }

        [DisplayName("Nivel Inventario")]
        public float Nivel_Inventario { get; set; }

        [DisplayName("Dist. Inventario")]
        public int DistInventario { get; set; }

        [DisplayName("Decto. Autorizado Max.")]
        public float Descuento_Aut_Max { get; set; }

        [DisplayName("Estado")]
        public int estado { get; set; }

        [DisplayName("Tipo")]
        public int tipo { get; set; }

        [DisplayName("Alias")]
        public string ALIAS { get; set; }
    }
}
