﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace SILACRUD.Models
{
    public class UsuariosModel
    {
        [DisplayName("Nombre Usuario")]
        public string usuarios { get; set; } = null!;
        
        [DisplayName("Permisos")]
        public string permisos { get; set; }

        [DisplayName("Estado")]
        public int estado { get; set; }




    }
}
