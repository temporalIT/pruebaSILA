﻿using System.ComponentModel;


namespace SILACRUD.Models
{
    public class PromotorModel
    {
        [DisplayName("No. Promotor")]
        public float? promotor { get; set; } = null!;

        [DisplayName("Abreviatura Pais")]
        public string pais { get; set; } = null!;

        [DisplayName("Nombre Promotor")]
        public string nombre { get; set; }

        [DisplayName("Correo")]
        public string correo { get; set; }

        [DisplayName("cc")]
        public string cc { get; set; } = null!;

        [DisplayName("cco")]
        public string cco { get; set; } = null!;

        [DisplayName("Estado")]
        public int estado { get; set; }

        [DisplayName("Tipo")]
        public string tipo { get; set; }

        
        public PaisModel Pais { get; set; }







    }
}
