﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace SILACRUD.Models
{
    public class ZonasModel
    {

        [DisplayName("Código de Zona")]
        public int? codigo { get; set; } = null!;

        [DisplayName("País")]
        public string pais { get; set; }

        [DisplayName("Zona")]
        public string zonas { get; set; }

        [DisplayName("Descripción")]
        public string descripcion { get; set; } = null!;

        [DisplayName("Promotor")]
        public float promotor { get; set; }

        [DisplayName("Estado")]
        public int estado { get; set; }


    }
}
