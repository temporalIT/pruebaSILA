﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace SILACRUD.Models
{
    public class ZonasdetalleModel
    {
        [DisplayName("ID")]
        public int? id { get; set; } = null!;

        [DisplayName("Codigo Zona")]
        public int? zona { get; set; } = null!;

        [DisplayName("Cliente")]
        [Column(TypeName = "decimal(13, 0)")]
        public decimal? cliente { get; set; } = null!;

        [DisplayName("Estado")]
        public int estado { get; set; }

        public ZonasModel zonas { get; set; }







    }
}
