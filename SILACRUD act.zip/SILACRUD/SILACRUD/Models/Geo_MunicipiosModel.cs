﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SILACRUD.Models
{
    public class Geo_MunicipiosModel
    {
        [DisplayName("Municipio")]
        public string id { get; set; } = null!;

        [DisplayName("Ref. Departamento")]
        public string refdepartamento { get; set; } = null!;

        [DisplayName("Departamento")]
        public int? departamento { get; set; } = null!;

        [DisplayName("Codigo Municipio")]
        public int? codigomunicipio { get; set; } = null!;

        [DisplayName("Nombre")]
        public string nombre { get; set; }
    }
}
